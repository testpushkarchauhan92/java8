package com.java8.eg0069;

@FunctionalInterface
public interface Foo {
	public abstract String method(String name);
}
