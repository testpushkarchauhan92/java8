package com.java8.eg0025;

@FunctionalInterface
public interface Operation {
	public abstract void operate(int n);
}
