package com.java8.eg000;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExceptionHandling03 {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandling03.class);

	public static void main(String[] args) {
		try {
			int a = 0;
			int b = 7 / a;
			LOGGER.info("Division result : {}", b);
			LOGGER.info("After Exception");
		} catch (ArithmeticException e) {
			LOGGER.error("Divide by Zero : {} with exception : {}", e.getMessage(), e);
		}
		LOGGER.info("After catch statement");

	}

}
