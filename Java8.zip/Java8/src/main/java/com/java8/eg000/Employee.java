package com.java8.eg000;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Employee {

	private int id;
	private String name;
	private String company;
	private String email;

}
