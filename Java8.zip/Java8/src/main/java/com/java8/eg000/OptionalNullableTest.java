package com.java8.eg000;


import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OptionalNullableTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(OptionalNullableTest.class);

	private static Map<String, Employee> empCache = new HashMap<>();

	private static Map<String, Employee> initCache() {
		empCache.put("TCS", new Employee(1, "AAA", "TCS", "AAA@gmail.com"));
		empCache.put("Infosys", new Employee(3, "DDD", "LTI", "DDD@gmail.com"));
		empCache.put("CG", new Employee(8, "KKK", "CG", "KKK@gmail.com"));
		empCache.put("CGI", new Employee(10, "PPP", "CGI", "PPP@gmail.com"));
		return empCache;
	}

	public static void main(String[] args) {
		empCache = initCache();
		String[] companyArr = { "TCS", "Infosys", "DXC", "LTI", "CG", "Harman" };

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("-".repeat(100));
		}

		Arrays.stream(companyArr)
				.forEach(str -> Optional.ofNullable(empCache.get(str))
										.ifPresent(emp -> LOGGER.info("s {}", emp)));

		Arrays.stream(companyArr).forEach(str -> Optional.ofNullable(empCache.get(str))
														 .ifPresentOrElse(emp -> LOGGER.info("s {}", emp), 
																 		  () -> LOGGER.info("*****")));

	}

}
