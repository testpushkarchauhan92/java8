package com.java8.eg000;


import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExceptionHandling04 {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandling04.class);

	public static void main(String[] args) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("-".repeat(100));
		}
		performExceptionHandling2();
	}

	public static void performExceptionHandling1() {
		try {
			int a = 0;
			int b = 7 / a;
			LOGGER.info("Division result : {}", b);
			LOGGER.info("After Exception");
		} catch (ArithmeticException e) {
			LOGGER.error("Divide by Zero : {} with exception : {}", e.getMessage(), e);
		}
		LOGGER.info("After catch statement");
	}

	public static void performExceptionHandling2() {
		int b = 0;
		List<Integer> numbers = new LinkedList<>();
		numbers.add(9);
		numbers.add(3);
		numbers.add(0);
		numbers.add(1);

		for (Integer num : numbers) {
			try {
				if (LOGGER.isInfoEnabled() && num != null) {
					LOGGER.info(String.format("value is %d", num));
				}
				b = 30 / num;
			} catch (ArithmeticException e) {
				LOGGER.info("Division by Zero");
				b = 0;
			}
			LOGGER.info("Value of b : {}", b);
		}
		LOGGER.info("After loop");

	}

}
