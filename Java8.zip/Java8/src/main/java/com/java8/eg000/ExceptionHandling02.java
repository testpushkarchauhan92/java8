package com.java8.eg000;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExceptionHandling02 {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandling02.class);

	public static void main(String[] args) {
		int a = 0;
		int b = 7 / a;
		LOGGER.info("After exception");

	}

}
