package com.java8.eg000;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExceptionHandlingMultipleCatchBlock05 {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandlingMultipleCatchBlock05.class);

	public static void main(String[] args) {
		calculateValue(0);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("-".repeat(100));
		}
		calculateValue(2);
	}

	public static void calculateValue(int i) {
		int[] nums = { 0 };
		try {
			int b = 7 / nums[i];
			LOGGER.info("Division result : {}", b);
			LOGGER.info("After Exception");
		} catch (ArithmeticException e) {
			LOGGER.info("Division by Zero");
		} catch (ArrayIndexOutOfBoundsException e) {
			LOGGER.info("Array Index Out of Bounds");
		}

	}

}
