package com.java8.eg000;


import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExceptionHandling01DivisionTester {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandling01DivisionTester.class);

	public static void main(String[] args) {

		// withoutExceptionHandling();
		//withExceptionHandling();
		withExceptionHandlingTryWithResources();

	}

	public static void withoutExceptionHandling() {
		Scanner sc = new Scanner(System.in);
		LOGGER.info("Enter Dividend :");
		int dividend = sc.nextInt();
		LOGGER.info("Enter Divisor :");
		int divisor = sc.nextInt();
		int result = dividend / divisor;
		LOGGER.info("Result of division : {}", result);
		sc.close();
	}

	public static void withExceptionHandling() {
		Scanner sc = null;
		try {
			sc = new Scanner(System.in);
			LOGGER.info("Enter Dividend :");
			int dividend = sc.nextInt();
			LOGGER.info("Enter Divisor :");
			int divisor = sc.nextInt();
			int result = dividend / divisor;
			LOGGER.info("Result of division : {}", result);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (sc != null) {
				sc.close();
			}
		}
	}

	// Java 7 feature of autocloseable since Scanner implements autocloseable we can use it with try with resources
	public static void withExceptionHandlingTryWithResources() {
		try (Scanner sc = new Scanner(System.in)) {
			LOGGER.info("Enter Dividend :");
			int dividend = sc.nextInt();
			LOGGER.info("Enter Divisor :");
			int divisor = sc.nextInt();
			int result = dividend / divisor;
			LOGGER.info("Result of division : {}", result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
