package com.java8.eg0002;

public class MyInterfaceTester {

	public static void main(String[] args) {

		MyInterface.greet("Pushkar");

	}

}
