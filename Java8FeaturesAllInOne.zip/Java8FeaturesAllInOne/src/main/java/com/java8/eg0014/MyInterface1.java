package com.java8.eg0014;

@FunctionalInterface
public interface MyInterface1 {
	public abstract boolean test(int n1, int n2);
}
