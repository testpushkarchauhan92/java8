package com.java8.eg0020;

@FunctionalInterface
public interface MyComparator {
	public abstract boolean compare(int n1, int n2);
}
