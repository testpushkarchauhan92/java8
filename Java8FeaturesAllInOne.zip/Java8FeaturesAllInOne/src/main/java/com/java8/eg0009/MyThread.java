package com.java8.eg0009;

public class MyThread implements Runnable {

	@Override
	public void run() {
		System.out.println("My Task is executing...");
	}

}
