package com.java8.eg0012;

@FunctionalInterface
public interface MyInterface1 {
	public abstract void m1(String name);
}
