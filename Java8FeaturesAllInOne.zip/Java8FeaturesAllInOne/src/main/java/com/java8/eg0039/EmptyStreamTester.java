package com.java8.eg0039;

import java.util.stream.Stream;

public class EmptyStreamTester {

	public static void main(String[] args) {

		Stream<String> emptyStream = Stream.empty();
	}

}
